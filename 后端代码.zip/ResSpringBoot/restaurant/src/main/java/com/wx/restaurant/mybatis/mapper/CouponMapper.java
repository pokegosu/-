package com.wx.restaurant.mybatis.mapper;

import com.wx.restaurant.mybatis.model.Coupon;
import com.wx.restaurant.util.MyMapper;

public interface CouponMapper extends MyMapper<Coupon> {
}