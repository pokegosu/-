package com.wx.restaurant.mybatis.mapper;

import com.wx.restaurant.mybatis.model.DishType;
import com.wx.restaurant.util.MyMapper;

public interface DishTypeMapper extends MyMapper<DishType> {
}