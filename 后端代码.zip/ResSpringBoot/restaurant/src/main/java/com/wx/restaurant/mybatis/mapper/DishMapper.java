package com.wx.restaurant.mybatis.mapper;

import com.wx.restaurant.mybatis.model.Dish;
import com.wx.restaurant.util.MyMapper;

public interface DishMapper extends MyMapper<Dish> {
}