package com.wx.restaurant.mybatis.mapper;

import com.wx.restaurant.mybatis.model.MyCoupon;
import com.wx.restaurant.util.MyMapper;

public interface MyCouponMapper extends MyMapper<MyCoupon> {
}